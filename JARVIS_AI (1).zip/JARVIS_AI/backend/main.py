import hmac
import os
from typing import List, Optional

import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

app = FastAPI(title="JARVIS AI Backend")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
APP_TOKEN = os.getenv("APP_TOKEN", "")

LANG_NAMES = {"hi-IN": "Hindi", "ne-NP": "Nepali", "en-IN": "English"}


class Turn(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    message: str
    language: str = "hi-IN"
    history: List[Turn] = []


def system_prompt(lang_code: str) -> str:
    lang = LANG_NAMES.get(lang_code, "Hindi")
    return (
        "You are JARVIS, a friendly personal voice assistant on the user's Android phone. "
        f"Reply in {lang} unless the user clearly writes in another language. "
        "Keep answers short and natural, because they will be read aloud. "
        "Avoid markdown, lists with symbols, and emojis."
    )


def clean_history(history: List[Turn]) -> List[Turn]:
    h = [t for t in history[-12:] if t.role in ("user", "assistant") and t.content.strip()]
    while h and h[0].role != "user":
        h.pop(0)
    return h


async def call_openai(req: ChatRequest) -> str:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY not set")
    msgs = [{"role": "system", "content": system_prompt(req.language)}]
    msgs += [{"role": t.role, "content": t.content} for t in clean_history(req.history)]
    msgs.append({"role": "user", "content": req.message})
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
            json={"model": OPENAI_MODEL, "messages": msgs},
        )
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


async def call_gemini(req: ChatRequest) -> str:
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY not set")
    contents = [
        {"role": "user" if t.role == "user" else "model", "parts": [{"text": t.content}]}
        for t in clean_history(req.history)
    ]
    contents.append({"role": "user", "parts": [{"text": req.message}]})
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent",
            headers={"x-goog-api-key": GEMINI_API_KEY},
            json={
                "system_instruction": {"parts": [{"text": system_prompt(req.language)}]},
                "contents": contents,
            },
        )
    r.raise_for_status()
    parts = r.json()["candidates"][0]["content"]["parts"]
    return "".join(p.get("text", "") for p in parts).strip()


@app.get("/")
def health():
    return {
        "status": "ok",
        "openai": bool(OPENAI_API_KEY),
        "gemini": bool(GEMINI_API_KEY),
    }


@app.post("/chat")
async def chat(req: ChatRequest, x_app_token: Optional[str] = Header(default=None)):
    if APP_TOKEN and not hmac.compare_digest(x_app_token or "", APP_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid app token")

    errors = []
    for name, fn in (("openai", call_openai), ("gemini", call_gemini)):
        try:
            reply = await fn(req)
            if reply:
                return {"reply": reply, "provider": name}
            errors.append(f"{name}: empty reply")
        except Exception as e:  # fall through to the next provider
            errors.append(f"{name}: {type(e).__name__}")
    raise HTTPException(status_code=503, detail="; ".join(errors))
