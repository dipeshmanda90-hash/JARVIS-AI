# JARVIS AI

Android ऐप (Kotlin) + FastAPI backend (OpenAI पहले, Gemini बैकअप)।

## 1. APK बनाना
1. इस फोल्डर की सारी फाइलें GitHub repo के मुख्य पेज पर अपलोड करें (`.github` सहित)।
2. Actions → Build JARVIS AI APK → Run workflow।
3. Artifact `JARVIS-AI-debug-APK` डाउनलोड करें, ZIP खोलें, `app-debug.apk` इंस्टॉल करें।

## 2. Backend चालू करना (Render.com)
1. render.com पर New → Web Service → अपनी GitHub repo चुनें।
2. Root Directory: `backend`
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Environment Variables में डालें:
   - `OPENAI_API_KEY`
   - `GEMINI_API_KEY`
   - `APP_TOKEN` (कोई भी लंबा गुप्त शब्द)
   - (वैकल्पिक) `OPENAI_MODEL`, `GEMINI_MODEL`
6. Deploy के बाद मिला `https://....onrender.com` लिंक खोलकर देखें: `{"status":"ok"...}` आना चाहिए।

## 3. ऐप में जोड़ना
ऐप खोलें → ऊपर सेटिंग्स आइकन → Backend URL और App Token डालें → सेव।

API keys कभी ऐप या GitHub कोड में न रखें।
