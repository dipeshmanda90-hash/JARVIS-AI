package com.jarvis.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private data class Lang(val label: String, val code: String)

    private val langs = listOf(
        Lang("हिंदी", "hi-IN"),
        Lang("नेपाली", "ne-NP"),
        Lang("English", "en-IN")
    )

    private val messages = mutableListOf<Msg>()
    private lateinit var adapter: MsgAdapter
    private lateinit var recycler: RecyclerView
    private lateinit var input: EditText
    private lateinit var progress: ProgressBar
    private lateinit var langSpinner: Spinner
    private lateinit var speakCheck: CheckBox
    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    private val prefs by lazy { getSharedPreferences("jarvis", Context.MODE_PRIVATE) }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private val voiceLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val text = result.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                if (!text.isNullOrBlank()) send(text)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler = findViewById(R.id.recycler)
        input = findViewById(R.id.input)
        progress = findViewById(R.id.progress)
        langSpinner = findViewById(R.id.langSpinner)
        speakCheck = findViewById(R.id.speakCheck)

        adapter = MsgAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        recycler.adapter = adapter

        langSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, langs.map { it.label }
        )
        langSpinner.setSelection(prefs.getInt("lang", 0).coerceIn(0, langs.size - 1))
        langSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("lang", pos).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        tts = TextToSpeech(this) { status -> ttsReady = status == TextToSpeech.SUCCESS }

        findViewById<ImageButton>(R.id.sendBtn).setOnClickListener { sendFromInput() }
        findViewById<ImageButton>(R.id.micBtn).setOnClickListener { startVoice() }
        findViewById<ImageButton>(R.id.settingsBtn).setOnClickListener { openSettings() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendFromInput(); true } else false
        }

        addMessage(Msg(false, "नमस्ते! मैं JARVIS हूँ। माइक दबाकर बोलिए या लिखकर पूछिए।"))
        if (prefs.getString("url", "").isNullOrBlank()) openSettings()
    }

    private fun currentLang(): Lang = langs[langSpinner.selectedItemPosition.coerceIn(0, langs.size - 1)]

    private fun addMessage(m: Msg) {
        messages.add(m)
        adapter.notifyItemInserted(messages.size - 1)
        recycler.scrollToPosition(messages.size - 1)
    }

    private fun sendFromInput() {
        val t = input.text.toString().trim()
        if (t.isNotEmpty()) {
            input.setText("")
            send(t)
        }
    }

    private fun startVoice() {
        val lang = currentLang()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.code)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए…")
        }
        try {
            voiceLauncher.launch(i)
        } catch (e: Exception) {
            Toast.makeText(this, "इस फ़ोन में Google वॉइस इनपुट उपलब्ध नहीं है", Toast.LENGTH_LONG).show()
        }
    }

    private fun openSettings() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        val urlEt = EditText(this).apply {
            hint = "Backend URL (https://...)"
            setText(prefs.getString("url", ""))
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val tokEt = EditText(this).apply {
            hint = "App Token (backend में APP_TOKEN)"
            setText(prefs.getString("token", ""))
        }
        box.addView(urlEt)
        box.addView(tokEt)
        AlertDialog.Builder(this)
            .setTitle("सेटिंग्स")
            .setView(box)
            .setPositiveButton("सेव") { _, _ ->
                prefs.edit()
                    .putString("url", urlEt.text.toString().trim())
                    .putString("token", tokEt.text.toString().trim())
                    .apply()
            }
            .setNegativeButton("रद्द", null)
            .show()
    }

    private fun send(text: String) {
        var url = prefs.getString("url", "").orEmpty().trim()
        if (url.isEmpty()) { openSettings(); return }
        if (!url.startsWith("http")) url = "https://$url"

        addMessage(Msg(true, text))

        val hist = JSONArray()
        messages.dropLast(1).takeLast(10).forEach { m ->
            hist.put(
                JSONObject()
                    .put("role", if (m.fromUser) "user" else "assistant")
                    .put("content", m.text)
            )
        }
        val body = JSONObject()
            .put("message", text)
            .put("language", currentLang().code)
            .put("history", hist)

        val req = try {
            val b = Request.Builder()
                .url(url.trimEnd('/') + "/chat")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
            val token = prefs.getString("token", "").orEmpty()
            if (token.isNotEmpty()) b.header("X-App-Token", token)
            b.build()
        } catch (e: Exception) {
            addMessage(Msg(false, "Backend URL सही नहीं है। सेटिंग्स में जाँचिए।"))
            return
        }

        progress.visibility = View.VISIBLE
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    addMessage(Msg(false, "कनेक्शन में समस्या: ${e.message}"))
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    val s = r.body?.string().orEmpty()
                    val reply = if (r.isSuccessful) {
                        try { JSONObject(s).getString("reply") } catch (e: Exception) { "जवाब पढ़ने में गड़बड़ी हुई।" }
                    } else {
                        "सर्वर त्रुटि (${r.code}): ${s.take(200)}"
                    }
                    runOnUiThread {
                        progress.visibility = View.GONE
                        addMessage(Msg(false, reply))
                        if (r.isSuccessful) speak(reply)
                    }
                }
            }
        })
    }

    private fun speak(text: String) {
        if (!ttsReady || !speakCheck.isChecked) return
        tts.language = Locale.forLanguageTag(currentLang().code)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
