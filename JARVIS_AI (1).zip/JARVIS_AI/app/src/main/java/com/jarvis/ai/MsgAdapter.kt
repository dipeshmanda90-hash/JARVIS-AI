package com.jarvis.ai

import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Msg(val fromUser: Boolean, val text: String)

class MsgAdapter(private val items: List<Msg>) : RecyclerView.Adapter<MsgAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tv: TextView = v.findViewById(R.id.msgText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.tv.text = m.text
        val lp = holder.tv.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (m.fromUser) Gravity.END else Gravity.START
        holder.tv.layoutParams = lp
        holder.tv.setBackgroundResource(if (m.fromUser) R.drawable.bubble_user else R.drawable.bubble_ai)
    }

    override fun getItemCount() = items.size
}
